from abc import ABC, abstractmethod, ABCMeta
# from Visitor import Visitor
from dataclasses import dataclass
from typing import List, Tuple


class AST(ABC):
    def __eq__(self, other):
        return self.__dict__ == other.__dict__

    def accept(self, v, param):
        method_name = 'visit{}'.format(self.__class__.__name__)
        visit = getattr(v, method_name)
        return visit(self, param)


class Stmt(AST):
    pass


class Expr(Stmt):
    pass


class Type(AST):
    pass


class Decl(AST):
    pass

# Types


class AtomicType(Type):
    pass


class IntegerType(AtomicType):
    def __str__(self):
        return self.__class__.__name__


class FloatType(AtomicType):
    def __str__(self):
        return self.__class__.__name__


class BooleanType(AtomicType):
    def __str__(self):
        return self.__class__.__name__


class StringType(AtomicType):
    def __str__(self):
        return self.__class__.__name__


class ArrayType(Type):
    def __init__(self, dimensions: List[int], typ: AtomicType):
        self.dimensions = dimensions
        self.typ = typ

    def __str__(self):
        return "ArrayType([{}], {})".format(", ".join([dimen for dimen in self.dimensions]), str(self.typ))


class AutoType(Type):
    def __str__(self):
        return self.__class__.__name__


class VoidType(Type):
    def __str__(self):
        return self.__class__.__name__


# Expressions

class LHS(Expr):
    pass


class BinExpr(Expr):
    def __init__(self, op: str, left: Expr, right: Expr):
        self.op = op
        self.left = left
        self.right = right


class UnExpr(Expr):
    def __init__(self, op: str, val: Expr):
        self.op = str
        self.val = val


class Id(LHS):
    def __init__(self, name: str):
        self.name = name


class ArrayCell(LHS):
    def __init__(self, name: str, cell: List[Expr]):
        self.name = name
        self.cell = cell


class IntegerLit(Expr):
    def __init__(self, val: int):
        self.val = val


class FloatLit(Expr):
    def __init__(self, val: float):
        self.val = val


class StringLit(Expr):
    def __init__(self, val: str):
        self.val = val


class BooleanLit(Expr):
    def __init__(self, val: bool):
        self.val = val


class FuncCall(Expr):
    def __init__(self, name: str, args: List[Expr]):
        self.name = name
        self.args = args


# Statements

class AssignStmt(Stmt):
    def __init__(self, lhs: LHS, rhs: Expr):
        self.lhs = lhs
        self.rhs = rhs


class BlockStmt(Stmt):
    def __init__(self, body: List[Stmt or VarDecl]):
        self.body = body


class IfStmt(Stmt):
    def __init__(self, cond: Expr, tstmt: Stmt, fstmt: Stmt or None):
        self.cond = cond
        self.tstmt = tstmt
        self.fstmt = fstmt


class ForStmt(Stmt):
    def __init__(self, init: AssignStmt, cond: Expr, upd: Expr, stmt: Stmt):
        self.init = init
        self.cond = cond
        self.upd = upd
        self.stmt = stmt


class WhileStmt(Stmt):
    def __init__(self, cond: Expr, stmt: Stmt):
        self.cond = cond
        self.stmt = stmt


class DoWhile(Stmt):
    def __init__(self, cond: Expr, stmt: BlockStmt):
        self.cond = cond
        self.stmt = stmt


class BreakStmt(Stmt):
    pass


class ContinueStmt(Stmt):
    pass


class ReturnStmt(Stmt):
    def __init__(self, expr: Expr or None):
        self.expr = expr


class CallStmt(Stmt):
    def __init__(self, name: LHS, args: List[Expr]):
        self.name = name
        self.args = args


# Declarations


class VarDecl(Decl):
    def __init__(self, name: str, typ: Type):
        self.name = name
        self.typ = typ

    def __str__(self):
        return "VarDecl({}, {})".format(name, str(self.typ))


class ParamDecl(Decl):
    def __init__(self, name: str, typ: Type, out: bool):
        self.name = name
        self.typ = typ
        self.out = out

    def __str__(self):
        if self.out:
            return "OutParam({}, {})".format()


class FuncDecl(Decl):
    def __init__(self, name: str, returnType: Type, params: List[ParamDecl], inherit: str or None, body: BlockStmt):
        self.name = name
        self.returnType = returnType
        self.params = params
        self.inherit = inherit
        self.body = body

    def __str__(self):
        return "FuncDecl({}, {}, {}, {}, {})".format(self.name)

# Program


class Program(AST):
    def __init__(self, decls: List[Decl]):
        self.decls = decls

    def __str__(self):
        return "Program([\n{}\n])".format("\n".join([str(decl) for decl in self.decls]))
